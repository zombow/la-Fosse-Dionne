using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerManager : MonoBehaviour
{
    
    public PlayerStats playerStats; // 플레이어 능력치
    void Start()
    {
        
    }

    public void PlayerInit()
    {
        
    }
 
}
